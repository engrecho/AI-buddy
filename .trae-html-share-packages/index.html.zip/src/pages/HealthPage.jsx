import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { Heart, Plus, Calendar as CalendarIcon, Pill, ChevronLeft, Trash2, Clock, AlertCircle, X, Camera, Check, Shield, RotateCw } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogFooter } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { lunarDateText } from '@/lib/lunar';
import { LunarBirthdayPicker } from '@/components/LunarBirthdayPicker';

// ════════════════════════════════════════════════════════════════════
// 设计系统（统一字号 / 间距 / 触摸目标）
// 移动端优先：所有可点击元素最小 36px，字号统一用 Tailwind 标准档
//   text-xs(12px)  = 标签 / 元信息
//   text-sm(14px)  = 正文 / 卡片标题
//   text-base(16px)= 页面标题
//   禁止使用 text-[10px] / text-[11px] / text-[9px] 等任意值
// ════════════════════════════════════════════════════════════════════

// ── API 工具 ────────────────────────────────────────────────
function getAuthHeaders(json = false) {
  const headers = {};
  try {
    const token = localStorage.getItem('ai_buddy_token');
    if (token) headers['Authorization'] = `Bearer ${token}`;
  } catch {}
  if (json) headers['Content-Type'] = 'application/json';
  return headers;
}

async function api(path, options = {}) {
  const opts = {
    credentials: 'include',
    ...options,
    headers: { ...getAuthHeaders(!!options.body && !(options.body instanceof FormData)), ...(options.headers || {}) },
  };
  if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
    opts.body = JSON.stringify(options.body);
  }
  const res = await fetch(path, opts);
  if (res.status === 401) {
    try { localStorage.removeItem('ai_buddy_token'); } catch {}
    window.location.hash = '#/login';
    return { data: null, error: { message: '未登录' } };
  }
  return res.json();
}

// 原图 URL → 缩略图 URL（/api/health/images/xxx.jpg → /api/health/thumb/xxx.jpg?w=300）
function toThumbUrl(url, width = 300) {
  if (!url) return url;
  const m = url.match(/\/api\/health\/images\/(.+)$/);
  if (m) return `/api/health/thumb/${m[1]}?w=${width}`;
  return url;
}

// 上传健康图片（药物照片、就诊附件等）
async function uploadHealthImage(file) {
  const formData = new FormData();
  formData.append('file', file);
  const token = localStorage.getItem('ai_buddy_token');
  const res = await fetch('/api/health/upload', {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    credentials: 'include',
    body: formData,
  });
  const r = await res.json();
  if (r.error) { toast.error(r.error.message); return null; }
  return r.data?.url || null;
}

// 清理表单数据：空字符串 → null，删除 id 字段
function cleanForm(form) {
  const cleaned = { ...form };
  delete cleaned.id;
  for (const key of Object.keys(cleaned)) {
    if (cleaned[key] === '') cleaned[key] = null;
  }
  return cleaned;
}

const COLOR_OPTIONS = ['#ec4899', '#f59e0b', '#10b981', '#06b6d4', '#6366f1', '#8b5cf6', '#ef4444', '#6b7280'];

function calcAge(birthDate) {
  if (!birthDate) return '';
  const d = new Date(birthDate);
  if (isNaN(d.getTime())) return '';
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
  return `${age}岁`;
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  return Math.round((d - now) / 86400000);
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
}

function formatDateRange(start, end) {
  if (!start && !end) return '';
  if (start && end) return `${formatDate(start)} ~ ${formatDate(end)}`;
  return formatDate(start || end);
}

function genderText(g) {
  return g === 'male' ? '男' : g === 'female' ? '女' : '';
}

// ISO 字符串 → <input type="date"> 需要的 YYYY-MM-DD 格式
// 后端返回 "2021-11-14T16:00:00.000Z"（UTC），需用本地时区还原正确日期
function toDateInputValue(v) {
  if (!v) return '';
  // 已经是 YYYY-MM-DD 格式，直接返回
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  const d = new Date(v);
  if (isNaN(d.getTime())) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// 把表单中所有日期字段从 ISO 转成 YYYY-MM-DD
function normalizeFormDates(form, dateFields) {
  const out = { ...form };
  for (const k of dateFields) {
    if (out[k]) out[k] = toDateInputValue(out[k]);
  }
  return out;
}

// ════════════════════════════════════════════════════════════════════
// 单图上传组件（药物照片）— 移动端响应式缩放
// ════════════════════════════════════════════════════════════════════
function SingleImageUpload({ value, onChange, label = '图片' }) {
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const url = await uploadHealthImage(file);
    setUploading(false);
    if (url) onChange(url);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div>
      {label && <label className="text-xs text-gray-500 mb-1.5 block">{label}</label>}
      <div className="flex items-center gap-3">
        {value ? (
          <div className="relative group flex-shrink-0">
            <img
              src={toThumbUrl(value, 200)}
              alt="预览"
              loading="lazy"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg object-cover border border-gray-200"
            />
            <button
              type="button"
              onClick={() => onChange(null)}
              className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center shadow-md transition-transform active:scale-90"
              aria-label="删除图片"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center gap-1 text-gray-400 hover:border-gray-400 hover:text-gray-500 transition-colors flex-shrink-0 active:scale-95"
          >
            {uploading ? (
              <span className="text-xs">上传中</span>
            ) : (
              <>
                <Camera className="w-5 h-5" />
                <span className="text-xs">添加</span>
              </>
            )}
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden" />
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════
// 多图上传组件（就诊附件，支持备注）— 移动端优化
// ════════════════════════════════════════════════════════════════════
function MultiImageUpload({ items = [], onChange, onPreviewImage }) {
  const [uploading, setUploading] = useState(false);
  const [editingIdx, setEditingIdx] = useState(null);
  const [draftNote, setDraftNote] = useState('');
  const fileRef = useRef(null);

  const handleFile = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setUploading(true);
    const newItems = [...items];
    for (const file of files) {
      const url = await uploadHealthImage(file);
      if (url) newItems.push({ url, note: '' });
    }
    onChange(newItems);
    setUploading(false);
    if (fileRef.current) fileRef.current.value = '';
  };

  const startEdit = (idx, note) => {
    setEditingIdx(idx);
    setDraftNote(note || '');
  };

  const confirmNote = (idx) => {
    onChange(items.map((it, i) => i === idx ? { ...it, note: draftNote } : it));
    setEditingIdx(null);
    setDraftNote('');
  };

  const cancelEdit = () => {
    setEditingIdx(null);
    setDraftNote('');
  };

  const removeItem = (idx) => {
    onChange(items.filter((_, i) => i !== idx));
    if (editingIdx === idx) cancelEdit();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs text-gray-500">附件图片</label>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="text-xs text-[#5a7a00] hover:text-[#2d4a00] flex items-center gap-1 px-2 py-1 rounded-md hover:bg-[#bbea3b]/20 transition-colors active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" /> {uploading ? '上传中...' : '添加图片'}
        </button>
      </div>
      <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleFile} className="hidden" />
      {items.length > 0 && (
        <div className="space-y-2">
          {items.map((item, idx) => (
            <div key={idx} className="flex gap-2 items-start p-2 rounded-lg bg-gray-50">
              <img
                src={toThumbUrl(item.url, 200)}
                alt={`附件${idx + 1}`}
                loading="lazy"
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-md object-cover flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
                onClick={() => onPreviewImage?.(item.url)}
              />
              <div className="flex-1 min-w-0">
                {editingIdx === idx ? (
                  <div className="flex items-center gap-1">
                    <input
                      value={draftNote}
                      onChange={e => setDraftNote(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') confirmNote(idx); if (e.key === 'Escape') cancelEdit(); }}
                      placeholder="输入备注"
                      autoFocus
                      className="flex-1 min-w-0 text-xs h-7 rounded border border-input bg-white px-2 ring-offset-background focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                    />
                    <button type="button" onClick={() => confirmNote(idx)} className="w-7 h-7 flex items-center justify-center text-green-600 hover:bg-green-50 rounded transition-colors active:scale-90" title="确认">
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button type="button" onClick={cancelEdit} className="w-7 h-7 flex items-center justify-center text-gray-400 hover:bg-gray-100 rounded transition-colors active:scale-90" title="取消">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => startEdit(idx, item.note)}
                    className="text-xs text-gray-500 hover:text-gray-700 text-left min-w-0 w-full py-1 px-1 rounded hover:bg-white transition-colors"
                  >
                    {item.note ? <span className="line-clamp-2 break-words">{item.note}</span> : <span className="text-gray-300">+ 添加备注</span>}
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => removeItem(idx)}
                className="w-7 h-7 flex items-center justify-center text-red-400 hover:text-red-500 hover:bg-red-50 rounded-md flex-shrink-0 transition-colors active:scale-90"
                aria-label="删除"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════
// 图片预览 Modal — 移动端支持双指缩放
// pointer-events-auto：Radix Dialog 打开时会将 body 置为 pointer-events:none，
// 预览层必须显式恢复事件响应，否则视觉上盖住弹窗却点不了关闭按钮
// ════════════════════════════════════════════════════════════════════
function ImagePreviewModal({ src, onClose, onRotated }) {
  const [rotating, setRotating] = useState(false);
  if (!src) return null;

  const rotate = async (e) => {
    e.stopPropagation();
    if (rotating) return;
    // 仅健康图片支持旋转（其余模块的图没有 rotate 接口）
    if (!src.startsWith('/api/health/images/')) return;
    setRotating(true);
    const r = await api('/api/health/rotate', { method: 'POST', body: { url: src } });
    setRotating(false);
    if (r.error) { toast.error(r.error.message); return; }
    toast.success('已旋转 90°');
    onRotated?.(r.data?.url);
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 touch-manipulation pointer-events-auto"
      onClick={onClose}
      onPointerDown={e => e.stopPropagation()}
    >
      <img
        src={src}
        alt="预览"
        className="max-w-[92vw] max-h-[88vh] object-contain rounded-lg"
        onClick={e => e.stopPropagation()}
      />
      <button
        className="absolute top-4 right-4 w-10 h-10 bg-white/20 text-white rounded-full flex items-center justify-center hover:bg-white/30 transition-colors active:scale-90"
        onClick={onClose}
        aria-label="关闭"
      >
        <X className="w-5 h-5" />
      </button>
      {src.startsWith('/api/health/images/') && (
        <button
          className="absolute top-4 left-4 h-10 px-4 bg-white/20 text-white text-sm rounded-full flex items-center gap-1.5 hover:bg-white/30 transition-colors active:scale-95 disabled:opacity-50"
          onClick={rotate}
          disabled={rotating}
          aria-label="旋转图片"
        >
          <RotateCw className="w-4 h-4" />
          {rotating ? '旋转中...' : '旋转'}
        </button>
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════
// 药物状态 Badge — 统一样式
// ════════════════════════════════════════════════════════════════════
function MedicationStatusBadge({ status }) {
  if (status === 'active') return <Badge className="text-xs bg-green-100 text-green-700 hover:bg-green-100">服用中</Badge>;
  if (status === 'stopped') return <Badge variant="secondary" className="text-xs">已停药</Badge>;
  if (status === 'as_needed') return <Badge className="text-xs bg-amber-100 text-amber-700 hover:bg-amber-100">酌情使用</Badge>;
  return null;
}

// ════════════════════════════════════════════════════════════════════
// 表单字段组件 — 统一 label + 内容布局
// ════════════════════════════════════════════════════════════════════
function Field({ label, required, children, className = '' }) {
  return (
    <div className={className}>
      <label className="text-xs text-gray-500 mb-1.5 block">
        {label}{required && <span className="text-red-400 ml-0.5">*</span>}
      </label>
      {children}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════
// 档案表单弹窗 — 移动端单列、桌面端双列
// ════════════════════════════════════════════════════════════════════
function ProfileFormDialog({ open, onClose, onSubmit, initial }) {
  const emptyForm = () => ({
    patient_name: '', patient_avatar_url: '', gender: 'unknown', birth_date: '', birth_lunar: false,
    disease_name: '', color: COLOR_OPTIONS[0], status: 'active', notes: '', member_id: '',
  });
  const [form, setForm] = useState(emptyForm());
  const [members, setMembers] = useState([]);

  useEffect(() => {
    if (open) {
      setForm(initial ? normalizeFormDates(initial, ['birth_date']) : emptyForm());
      // 载入家庭成员列表，供「关联家庭成员」选择
      api('/api/health_profiles?filter=deleted_at.is.null&order=patient_name:asc')
        .then(d => { if (Array.isArray(d.data)) setMembers(d.data); })
        .catch(() => {});
    }
  }, [open, initial]);

  // 选择家庭成员 → 自动带出姓名/性别/生日(含农历)/关系，并绑定 member_id
  const handleMemberSelect = (val) => {
    const m = members.find(x => String(x.id) === String(val));
    if (!m) return;
    setForm(f => ({
      ...f,
      member_id: m.id,
      patient_name: m.patient_name || f.patient_name,
      gender: m.gender || f.gender,
      birth_date: m.birth_date ? toDateInputValue(m.birth_date) : f.birth_date,
      birth_lunar: !!m.birth_lunar,
    }));
  };

  const handleSubmit = () => {
    if (!form.patient_name.trim()) { toast.error('请填写患者姓名'); return; }
    if (!form.disease_name.trim()) { toast.error('请填写疾病名称'); return; }
    onSubmit(cleanForm(form));
  };

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-lg mx-auto rounded-none sm:rounded-xl max-h-[100dvh] sm:max-h-[90dvh] overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-base">{initial ? '编辑档案' : '新建健康档案'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          {/* 关联家庭成员：选择后自动带出姓名/性别/生日(含农历)，并建立绑定关系 */}
          <Field label="关联家庭成员" className="!mt-0">
            <div className="flex items-center gap-2">
              <div className="flex-1 min-w-0">
                <Select value={form.member_id ? String(form.member_id) : ''} onValueChange={handleMemberSelect}>
                  <SelectTrigger>
                    {form.member_id
                      ? (() => { const m = members.find(x => String(x.id) === String(form.member_id)); return <SelectValue>{m ? `${m.patient_name}${m.relationship ? `（${m.relationship}）` : ''}` : ''}</SelectValue>; })()
                      : <SelectValue placeholder="选择家庭成员（选填）" />}
                  </SelectTrigger>
                  <SelectContent>
                    {members.length === 0 && (
                      <div className="px-3 py-2 text-xs text-gray-400">暂无家庭成员，可前往「设置 → 家庭成员」添加</div>
                    )}
                    {members.map(m => (
                      <SelectItem key={m.id} value={String(m.id)}>
                        {m.patient_name}{m.relationship ? `（${m.relationship}）` : ''}
                        {m.birth_date ? ` · ${toDateInputValue(m.birth_date)}` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-xs text-gray-400 mt-1">选中家人的姓名、性别、生日（含农历）会自动填充，并与该档案建立关联</p>
          </Field>
          <div className="flex flex-col sm:flex-row gap-4">
            <Field label="患者姓名" required className="flex-1 min-w-0">
              <Input value={form.patient_name} onChange={e => set('patient_name', e.target.value)} placeholder="如：张三 / 父亲" />
            </Field>
            <Field label="性别" className="w-full sm:w-28 flex-shrink-0">
              <Select value={form.gender} onValueChange={v => set('gender', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">男</SelectItem>
                  <SelectItem value="female">女</SelectItem>
                  <SelectItem value="unknown">未知</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 min-w-0">
              {/* 生日：阳历 / 农历 选择器（农历可直接选「腊月二十」并换算阳历） */}
              <LunarBirthdayPicker
                value={form.birth_date}
                lunar={!!form.birth_lunar}
                onValueChange={v => set('birth_date', v)}
                onLunarChange={v => set('birth_lunar', v)}
              />
            </div>
            <Field label="状态" className="flex-1 min-w-0">
              <Select value={form.status} onValueChange={v => set('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">跟踪中</SelectItem>
                  <SelectItem value="archived">已归档</SelectItem>
                </SelectContent>
              </Select>
            </Field>
          </div>
          <Field label="疾病名称" required>
            <Input value={form.disease_name} onChange={e => set('disease_name', e.target.value)} placeholder="如：高血压 / 2型糖尿病" />
          </Field>
          <Field label="标识颜色">
            <div className="flex gap-2 flex-wrap">
              {COLOR_OPTIONS.map(c => (
                <button key={c} type="button" onClick={() => set('color', c)}
                  className={`w-8 h-8 rounded-md transition-transform active:scale-90 hover:scale-110 ${form.color === c ? 'ring-2 ring-offset-2 ring-gray-400' : ''}`}
                  style={{ backgroundColor: c }}
                  aria-label={`颜色 ${c}`}
                />
              ))}
            </div>
          </Field>
          <Field label="备注">
            <Textarea value={form.notes} onChange={e => set('notes', e.target.value)} rows={2} placeholder="过敏史、特殊注意等" />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSubmit} className="bg-[#bbea3b] hover:bg-[#a8d435] text-black">保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ════════════════════════════════════════════════════════════════════
// 日期选择器 — Popover + Calendar，替代原生 input type="date"
// 不会自动弹出，需点击触发；支持中文 locale
// ════════════════════════════════════════════════════════════════════
function DateField({ value, onChange, placeholder = '选择日期', disabled }) {
  const date = value ? new Date(value + 'T00:00:00') : null;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          className="flex h-10 w-full items-center rounded-md border border-input bg-background px-3 py-2 text-sm text-left ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <CalendarIcon className="mr-2 h-4 w-4 text-gray-400 flex-shrink-0" />
          {value ? (
            <span className="text-gray-900">{format(date, 'yyyy-MM-dd')}</span>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={date}
          onSelect={(d) => onChange(d ? format(d, 'yyyy-MM-dd') : '')}
          locale={zhCN}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );
}

// ════════════════════════════════════════════════════════════════════
// 就诊记录表单 — 响应式：移动端单列 / PC端三栏布局
//   左：基本信息（日期/医院/科室/医生/费用/报销）
//   中：诊断记录（主诉/诊断/处方/检查/下次就诊/附件）
//   右：本次就诊用药清单（独立编辑）
// ════════════════════════════════════════════════════════════════════
function VisitFormDialog({ open, onClose, onSubmit, initial, profileId, lastVisit, visitMedications, onAddMedication, onPickMedication, onEditMedication, onDeleteMedication, onPreviewImage }) {
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    visit_date: today, hospital: '', department: '', doctor: '',
    chief_complaint: '', diagnosis: '', prescription: '', examination: '',
    next_visit_date: '', next_visit_date_end: '', cost: '',
    is_reimbursed: 0, reimburse_amount: '', attachment_urls: [],
  });
  const [showCopyPrompt, setShowCopyPrompt] = useState(false);

  useEffect(() => {
    if (open) {
      const base = {
        visit_date: today, hospital: '', department: '', doctor: '',
        chief_complaint: '', diagnosis: '', prescription: '', examination: '',
        next_visit_date: '', next_visit_date_end: '', cost: '',
        is_reimbursed: 0, reimburse_amount: '', attachment_urls: [],
      };
      if (initial) {
        const normalized = normalizeFormDates(initial, ['visit_date', 'next_visit_date', 'next_visit_date_end']);
        // 历史数据合并：diagnosis/prescription/examination 合并到 chief_complaint
        const mergedComplaint = [
          normalized.chief_complaint,
          normalized.prescription ? `用药：${normalized.prescription}` : '',
          normalized.examination ? `检查：${normalized.examination}` : '',
          normalized.diagnosis ? `诊断：${normalized.diagnosis}` : '',
        ].filter(Boolean).join('\n');
        setForm({
          ...base,
          ...normalized,
          chief_complaint: mergedComplaint,
          diagnosis: '',
          prescription: '',
          examination: '',
          // tinyint → boolean: 后端返回 0/1
          is_reimbursed: initial.is_reimbursed ? 1 : 0,
          reimburse_amount: initial.reimburse_amount != null ? String(initial.reimburse_amount) : '',
          attachment_urls: Array.isArray(initial.attachment_urls) ? initial.attachment_urls : [],
        });
        setShowCopyPrompt(false);
      } else {
        // 新建：如果有上次就诊记录，提示是否复制
        if (lastVisit) {
          setShowCopyPrompt(true);
        } else {
          setShowCopyPrompt(false);
        }
        setForm(base);
      }
    }
  }, [open, initial?.id, lastVisit, today]);

  const copyFromLast = (copyMeds) => {
    if (!lastVisit) return;
    const normalized = normalizeFormDates(lastVisit, ['next_visit_date', 'next_visit_date_end']);
    setForm(f => ({
      ...f,
      // 日期默认今日（不复制就诊日期）
      visit_date: today,
      hospital: normalized.hospital || '',
      department: normalized.department || '',
      doctor: normalized.doctor || '',
      chief_complaint: normalized.chief_complaint || '',
      diagnosis: '',
      prescription: '',
      examination: '',
      // 下次就诊日期清空（属于上次的计划，不复制）
      next_visit_date: '',
      next_visit_date_end: '',
      cost: '',
      is_reimbursed: 0,
      reimburse_amount: '',
      attachment_urls: [],
    }));
    setShowCopyPrompt(false);
    toast.success(copyMeds ? '已复制上次信息（不含用药，请到右侧添加）' : '已复制上次基本信息');
  };

  const handleSubmit = () => {
    if (!form.visit_date) { toast.error('请填写就诊日期'); return; }
    const cleaned = cleanForm(form);
    cleaned.profile_id = profileId;
    cleaned.cost = form.cost ? parseFloat(form.cost) : null;
    cleaned.is_reimbursed = form.is_reimbursed ? 1 : 0;
    cleaned.reimburse_amount = form.reimburse_amount ? parseFloat(form.reimburse_amount) : null;
    cleaned.attachment_urls = form.attachment_urls || [];
    // 主诉/用药/检查/诊断已合并到 chief_complaint，清空旧字段
    cleaned.prescription = null;
    cleaned.examination = null;
    cleaned.diagnosis = null;
    onSubmit(cleaned);
  };

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full sm:max-w-5xl mx-auto rounded-none sm:rounded-xl max-h-[100dvh] sm:max-h-[92dvh] overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-base">{initial ? '编辑就诊记录' : '新增就诊记录'}</DialogTitle>
        </DialogHeader>

        {/* 复制上次就诊提示 */}
        {showCopyPrompt && lastVisit && (
          <div className="mb-4 p-3 rounded-lg bg-blue-50 border border-blue-200 flex items-start gap-3">
            <AlertCircle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="text-xs text-blue-700 mb-1">
                检测到上次就诊记录（{formatDate(lastVisit.visit_date)} {lastVisit.hospital}），是否复制基本信息？
              </div>
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => copyFromLast(true)}
                  className="text-xs px-3 py-1.5 rounded-md bg-blue-500 text-white hover:bg-blue-600 active:scale-95 transition-all"
                >
                  复制基本信息
                </button>
                <button
                  onClick={() => setShowCopyPrompt(false)}
                  className="text-xs px-3 py-1.5 rounded-md bg-white text-blue-600 border border-blue-300 hover:bg-blue-50 active:scale-95 transition-all"
                >
                  不复制
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 移动端：单列布局 / PC：三栏布局 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 py-1">
          {/* 左栏：基本信息 */}
          <div className="space-y-4 lg:border-r lg:border-gray-100 lg:pr-5">
            <div className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 lg:hidden">
              <CalendarIcon className="w-4 h-4 text-blue-500" /> 基本信息
            </div>
            <Field label="就诊日期" required>
              <DateField value={form.visit_date || ''} onChange={v => set('visit_date', v)} placeholder="选择就诊日期" />
            </Field>
            <Field label="医院">
              <Input value={form.hospital || ''} onChange={e => set('hospital', e.target.value)} placeholder="如：市第一人民医院" />
            </Field>
            <div className="flex gap-3">
              <Field label="科室" className="flex-1 min-w-0">
                <Input value={form.department || ''} onChange={e => set('department', e.target.value)} placeholder="心内科" />
              </Field>
              <Field label="医生" className="w-28 flex-shrink-0">
                <Input value={form.doctor || ''} onChange={e => set('doctor', e.target.value)} />
              </Field>
            </div>

            {/* 报销 */}
            <Field label="是否报销">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => set('is_reimbursed', form.is_reimbursed ? 0 : 1)}
                  className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${form.is_reimbursed ? 'bg-green-500' : 'bg-gray-300'}`}
                  aria-pressed={!!form.is_reimbursed}
                >
                  <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${form.is_reimbursed ? 'translate-x-5' : ''}`} />
                </button>
                <span className="text-sm text-gray-600">{form.is_reimbursed ? '已报销' : '未报销'}</span>
              </div>
            </Field>
            {form.is_reimbursed && (
              <Field label="报销金额（元）">
                <Input type="number" step="0.01" value={form.reimburse_amount || ''} onChange={e => set('reimburse_amount', e.target.value)} placeholder="0.00" />
              </Field>
            )}

            <Field label="费用（元）">
              <Input type="number" step="0.01" value={form.cost || ''} onChange={e => set('cost', e.target.value)} placeholder="0.00" />
            </Field>
          </div>

          {/* 中栏：诊断记录 */}
          <div className="space-y-4 lg:border-r lg:border-gray-100 lg:pr-5">
            <div className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 lg:hidden">
              <AlertCircle className="w-4 h-4 text-amber-500" /> 诊断记录
            </div>
            <Field label="就诊详情（主诉 / 用药 / 检查 / 诊断）">
              <Textarea value={form.chief_complaint || ''} onChange={e => set('chief_complaint', e.target.value)} rows={6} placeholder="主诉、用药方案、检查报告、诊断结果等就诊详情" />
            </Field>

            {/* 下次就诊日期（单日期组件） */}
            <Field label="下次就诊日期（可选）">
              <DateField value={form.next_visit_date || ''} onChange={v => set('next_visit_date', v)} placeholder="选择下次就诊日期" />
            </Field>

            {/* 附件图片 */}
            <MultiImageUpload
              items={form.attachment_urls || []}
              onChange={items => set('attachment_urls', items)}
              onPreviewImage={onPreviewImage}
            />
          </div>

          {/* 右栏：本次就诊用药清单（独立编辑） */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-sm font-semibold text-gray-700">
                <Pill className="w-4 h-4 text-green-500" /> 本次用药
                {visitMedications?.length > 0 && (
                  <Badge variant="secondary" className="text-xs">{visitMedications.length}</Badge>
                )}
              </div>
              <div className="flex gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onPickMedication?.(initial?.id)}
                  disabled={!initial?.id}
                  className="h-7 text-xs active:scale-95"
                >
                  <Plus className="w-3 h-3 mr-1" /> 从药物库选择
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onAddMedication?.(initial?.id)}
                  disabled={!initial?.id}
                  className="h-7 text-xs active:scale-95"
                >
                  新建
                </Button>
              </div>
            </div>
            {!initial?.id ? (
              <div className="text-xs text-gray-400 py-6 text-center rounded-lg bg-gray-50 border border-dashed border-gray-200">
                保存就诊记录后可添加本次用药
              </div>
            ) : (visitMedications?.length === 0 ? (
              <p className="text-xs text-gray-400 py-6 text-center">暂无本次用药</p>
            ) : (
              <div className="space-y-2">
                {visitMedications.map(med => (
                  <div key={med.id} className="flex items-start gap-2 p-2 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                    <div
                      className="w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0 overflow-hidden bg-green-50 cursor-pointer"
                      onClick={() => med.photo_url && onPreviewImage?.(med.photo_url)}
                    >
                      {med.photo_url
                        ? <img src={toThumbUrl(med.photo_url, 200)} alt={med.name} loading="lazy" className="w-full h-full object-cover" />
                        : <Pill className="w-4 h-4 text-green-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-medium truncate">{med.name}</span>
                        <MedicationStatusBadge status={med.status} />
                      </div>
                      {med.dosage && <div className="text-xs text-gray-500 mt-0.5 truncate">{med.dosage}</div>}
                    </div>
                    <div className="flex gap-0.5 flex-shrink-0">
                      <button
                        onClick={() => onEditMedication?.(med)}
                        className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors active:scale-90"
                        aria-label="编辑药物"
                      >
                        <Pill className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => onDeleteMedication?.(med)}
                        className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors active:scale-90"
                        aria-label="删除药物"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSubmit} className="bg-[#bbea3b] hover:bg-[#a8d435] text-black">保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ════════════════════════════════════════════════════════════════════
// 药物表单 — 移动端单列
// ════════════════════════════════════════════════════════════════════
function MedicationFormDialog({ open, onClose, onSubmit, initial, profileId, visitId, visits = [] }) {
  const [form, setForm] = useState({
    name: '', photo_url: '', usage_instruction: '', dosage: '',
    start_date: '', end_date: '', status: 'active', notes: '',
    visit_ids: [],
  });

  useEffect(() => {
    if (open) {
      if (initial) {
        const normalized = normalizeFormDates(initial, ['start_date', 'end_date']);
        normalized.visit_ids = Array.isArray(initial.visit_ids) ? [...initial.visit_ids] : [];
        setForm(normalized);
      } else {
        setForm({
          name: '', photo_url: '', usage_instruction: '', dosage: '',
          start_date: '', end_date: '', status: 'active', notes: '',
          // 从就诊记录里点"新建药物"时默认关联当前就诊
          visit_ids: visitId ? [visitId] : [],
        });
      }
    }
  }, [open, initial, visitId]);

  const handleSubmit = () => {
    if (!form.name.trim()) { toast.error('请填写药物名称'); return; }
    const cleaned = cleanForm(form);
    cleaned.profile_id = profileId;
    cleaned.visit_ids = form.visit_ids || [];
    onSubmit(cleaned);
  };

  const toggleVisit = (vid) => {
    setForm(f => ({
      ...f,
      visit_ids: (f.visit_ids || []).includes(vid)
        ? f.visit_ids.filter(x => x !== vid)
        : [...(f.visit_ids || []), vid],
    }));
  };

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-lg mx-auto rounded-none sm:rounded-xl max-h-[100dvh] sm:max-h-[90dvh] overflow-y-auto overflow-x-hidden p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-base">{initial ? '编辑药物' : '新增药物'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <Field label="药物名称" required>
            <Input value={form.name} onChange={e => set('name', e.target.value)} placeholder="如：阿司匹林肠溶片" />
          </Field>

          {/* 药物图片 */}
          <SingleImageUpload
            value={form.photo_url || ''}
            onChange={url => set('photo_url', url)}
            label="药物图片"
          />

          <Field label="用量">
            <Input value={form.dosage || ''} onChange={e => set('dosage', e.target.value)} placeholder="如：每次1片，每日3次，饭后服" />
          </Field>
          <Field label="用药说明">
            <Textarea value={form.usage_instruction || ''} onChange={e => set('usage_instruction', e.target.value)} rows={2} placeholder="注意事项、禁忌等" />
          </Field>

          {/* 日期可空 */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Field label="开始日期" className="flex-1 min-w-0">
              <DateField value={form.start_date || ''} onChange={v => set('start_date', v)} placeholder="选择开始日期" />
            </Field>
            <Field label="结束日期" className="flex-1 min-w-0">
              <DateField value={form.end_date || ''} onChange={v => set('end_date', v)} placeholder="选择结束日期" />
            </Field>
          </div>

          {/* 状态：含「酌情使用」 */}
          <Field label="状态">
            <Select value={form.status} onValueChange={v => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="active">服用中</SelectItem>
                <SelectItem value="as_needed">酌情使用</SelectItem>
                <SelectItem value="stopped">已停药</SelectItem>
              </SelectContent>
            </Select>
          </Field>

          {/* 关联就诊记录（多选）：同一药物可出现在多次就诊中 */}
          <Field label="关联就诊记录">
            {visits.length === 0 ? (
              <p className="text-xs text-gray-400 py-2">暂无就诊记录</p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto rounded-lg border border-gray-100 p-2">
                {visits.map(v => {
                  const checked = (form.visit_ids || []).includes(v.id);
                  return (
                    <label
                      key={v.id}
                      className={`flex items-center gap-2.5 p-2 rounded-md cursor-pointer transition-colors text-xs ${checked ? 'bg-green-50 border border-green-200' : 'hover:bg-gray-50 border border-transparent'}`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleVisit(v.id)}
                        className="w-4 h-4 accent-[#bbea3b] flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0 leading-tight">
                        {/* 第一行：日期 + 科室（短信息，不会撑爆） */}
                        <div className="flex items-center gap-1.5 text-xs">
                          <span className="font-medium text-gray-800">{formatDate(v.visit_date)}</span>
                          {v.department ? <span className="text-gray-400">· {v.department}</span> : null}
                        </div>
                        {/* 第二行：医院名（可能超长，允许换行） */}
                        {v.hospital ? (
                          <div className="text-xs text-gray-500 mt-0.5 break-words">
                            {v.hospital}
                          </div>
                        ) : null}
                      </div>
                      {(v.medications || []).length > 0 && (
                        <span className="text-gray-400 flex-shrink-0">{v.medications.length} 药</span>
                      )}
                    </label>
                  );
                })}
              </div>
            )}
          </Field>

          <Field label="备注">
            <Textarea value={form.notes || ''} onChange={e => set('notes', e.target.value)} rows={2} />
          </Field>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSubmit} className="bg-[#bbea3b] hover:bg-[#a8d435] text-black">保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ════════════════════════════════════════════════════════════════════
// 药物选择器 — 从药物库选择已有药物加入本次就诊（多选）
// medications：该档案全部药物（药物库），currentMedIds：已在本次就诊中的药物 id
// ════════════════════════════════════════════════════════════════════
function MedPickerDialog({ open, onClose, onConfirm, onAddNew, medications = [], currentMedIds = [] }) {
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (open) { setSelected([]); setSearch(''); }
  }, [open]);

  const currentSet = new Set(currentMedIds);
  const keyword = search.trim().toLowerCase();
  const list = medications.filter(m =>
    !currentSet.has(m.id) && (!keyword || (m.name || '').toLowerCase().includes(keyword))
  );

  const toggle = (id) => {
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="w-full max-w-md mx-auto rounded-none sm:rounded-xl max-h-[85dvh] flex flex-col p-0">
        <DialogHeader className="p-4 pb-2">
          <DialogTitle className="text-base">从药物库选择</DialogTitle>
        </DialogHeader>
        <div className="px-4 pb-2">
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="搜索药物名称..." className="text-sm" />
        </div>
        <div className="flex-1 overflow-y-auto px-4 pb-2 min-h-[120px]">
          {list.length === 0 ? (
            <p className="text-xs text-gray-400 py-8 text-center">
              {medications.length === 0 || list.length === 0 && keyword ? '没有匹配的药物，可点下方"新建药物"' : '药物库为空'}
            </p>
          ) : (
            <div className="space-y-1.5">
              {list.map(m => {
                const checked = selected.includes(m.id);
                return (
                  <label
                    key={m.id}
                    className={`flex items-center gap-2.5 p-2.5 rounded-lg cursor-pointer transition-colors border ${checked ? 'bg-green-50 border-green-300' : 'border-gray-100 hover:bg-gray-50'}`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggle(m.id)}
                      className="w-4 h-4 accent-[#bbea3b] flex-shrink-0"
                    />
                    <div className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0 overflow-hidden bg-green-50">
                      {m.photo_url
                        ? <img src={toThumbUrl(m.photo_url, 200)} alt={m.name} loading="lazy" className="w-full h-full object-cover" />
                        : <Pill className="w-4 h-4 text-green-500" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-sm font-medium truncate">{m.name}</span>
                        <MedicationStatusBadge status={m.status} />
                      </div>
                      {m.dosage && <div className="text-xs text-gray-500 mt-0.5 truncate">{m.dosage}</div>}
                    </div>
                  </label>
                );
              })}
            </div>
          )}
        </div>
        <div className="p-4 pt-2 border-t border-gray-100 flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={onAddNew} className="flex-1">
            <Plus className="w-3.5 h-3.5 mr-1" /> 新建药物
          </Button>
          <Button
            size="sm"
            disabled={selected.length === 0}
            onClick={() => onConfirm(selected)}
            className="flex-1 bg-[#bbea3b] hover:bg-[#a8d435] text-black"
          >
            加入（{selected.length}）
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ════════════════════════════════════════════════════════════════════
// 主组件
// ════════════════════════════════════════════════════════════════════
const HealthPage = () => {
  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);

  const [profileDialog, setProfileDialog] = useState({ open: false, initial: null });
  const [visitDialog, setVisitDialog] = useState({ open: false, initial: null });
  const [medDialog, setMedDialog] = useState({ open: false, initial: null, visitId: null });
  const [medPicker, setMedPicker] = useState({ open: false, visitId: null });
  const [removeMedTarget, setRemoveMedTarget] = useState(null); // { visit_id, med }
  const [deleteTarget, setDeleteTarget] = useState(null);

  // 药物库：该档案全部药物（顶层未关联的 + 各就诊记录里的），按 id 去重
  // 服用中优先，其余按创建时间倒序
  const allMedications = useMemo(() => {
    if (!selectedProfile) return [];
    const map = new Map();
    for (const m of selectedProfile.medications || []) map.set(m.id, m);
    for (const v of selectedProfile.visits || []) {
      for (const m of v.medications || []) map.set(m.id, m);
    }
    return [...map.values()].sort((a, b) => {
      if ((a.status === 'active') !== (b.status === 'active')) return a.status === 'active' ? -1 : 1;
      return (b.created_at || '').localeCompare(a.created_at || '');
    });
  }, [selectedProfile]);

  const loadProfiles = useCallback(async () => {
    setLoading(true);
    const r = await api('/api/health/profiles/with-stats');
    if (r.data) setProfiles(r.data);
    else if (r.error) toast.error(r.error.message);
    setLoading(false);
  }, []);

  const loadDetail = useCallback(async (id) => {
    setDetailLoading(true);
    const r = await api(`/api/health/profiles/${id}/detail`);
    if (r.data) setSelectedProfile(r.data);
    else if (r.error) toast.error(r.error.message);
    setDetailLoading(false);
  }, []);

  useEffect(() => { loadProfiles(); }, [loadProfiles]);

  // ── 档案操作（PATCH 带 filter，body 不带 id）─────────────
  const saveProfile = async (form) => {
    const isNew = !profileDialog.initial;
    const id = profileDialog.initial?.id;
    const path = isNew ? '/api/health_profiles' : `/api/health_profiles?filter=eq:id:${id}&single=1&return=1`;
    const method = isNew ? 'POST' : 'PATCH';
    const r = await api(path, { method, body: form });
    if (r.error) { toast.error(r.error.message); return; }
    toast.success(isNew ? '档案已创建' : '已保存');
    setProfileDialog({ open: false, initial: null });
    loadProfiles();
    if (selectedProfile && selectedProfile.id === id) loadDetail(id);
  };

  // 最新一次就诊记录（visits 已按 visit_date DESC 排序，[0] 即最新，就诊弹窗"复制上次就诊"用）
  const latestVisit = selectedProfile?.visits?.[0] || null;

  const saveVisit = async (form) => {
    const isNew = !visitDialog.initial;
    const id = visitDialog.initial?.id;
    const path = isNew ? '/api/health_visits' : `/api/health_visits?filter=eq:id:${id}&single=1&return=1`;
    const method = isNew ? 'POST' : 'PATCH';
    const r = await api(path, { method, body: form });
    if (r.error) { toast.error(r.error.message); return; }
    toast.success(isNew ? '就诊记录已添加' : '已保存');
    setVisitDialog({ open: false, initial: null });
    if (selectedProfile) loadDetail(selectedProfile.id);
    loadProfiles();
  };

  const saveMed = async (form) => {
    const isNew = !medDialog.initial;
    const id = medDialog.initial?.id;
    const { visit_ids, ...medBody } = form;
    const path = isNew ? '/api/health_medications' : `/api/health_medications?filter=eq:id:${id}&single=1&return=1`;
    const method = isNew ? 'POST' : 'PATCH';
    const r = await api(path, { method, body: medBody });
    if (r.error) { toast.error(r.error.message); return; }
    // 同步药物的就诊关联（多对多，全量覆盖）
    const medId = isNew ? r.data?.id : id;
    if (medId) {
      const rr = await api('/api/health/medication-visits', {
        method: 'POST',
        body: { medication_id: medId, visit_ids: Array.isArray(visit_ids) ? visit_ids : [] },
      });
      if (rr.error) { toast.error('就诊关联保存失败：' + rr.error.message); return; }
    }
    toast.success(isNew ? '药物已添加' : '已保存');
    setMedDialog({ open: false, initial: null, visitId: null });
    if (selectedProfile) {
      // 就诊编辑弹窗还开着时同步刷新其 initial（用药列表实时更新），
      // VisitFormDialog 的表单依赖 initial?.id，不会被重置
      await loadDetail(selectedProfile.id);
      if (visitDialog.open && visitDialog.initial?.id) {
        // loadDetail 内 setSelectedProfile 是异步 state，这里从接口返回取最新数据
        const r2 = await api(`/api/health/profiles/${selectedProfile.id}/detail`);
        if (r2.data) {
          const freshVisit = (r2.data.visits || []).find(v => v.id === visitDialog.initial.id);
          if (freshVisit) setVisitDialog(d => ({ ...d, initial: freshVisit }));
        }
      }
    }
    loadProfiles();
  };

  // ── 从药物库批量加入本次就诊 ──
  const handleAddMedications = async (medIds) => {
    const visitId = medPicker.visitId;
    if (!visitId || !medIds?.length) return;
    const r = await api('/api/health/visit-medications', {
      method: 'POST',
      body: { visit_id: visitId, medication_ids: medIds },
    });
    if (r.error) { toast.error(r.error.message); return; }
    toast.success(`已加入 ${medIds.length} 个药物`);
    setMedPicker({ open: false, visitId: null });
    if (selectedProfile) {
      // 同步刷新就诊弹窗的用药列表
      const r2 = await api(`/api/health/profiles/${selectedProfile.id}/detail`);
      if (r2.data) {
        setSelectedProfile(r2.data);
        const freshVisit = (r2.data.visits || []).find(v => v.id === visitId);
        if (freshVisit) setVisitDialog(d => ({ ...d, initial: freshVisit }));
      }
    }
  };

  // ── 从本次就诊移除药物（仅解除关联，药物保留在药物库） ──
  const handleRemoveMedFromVisit = async () => {
    if (!removeMedTarget) return;
    const { visit_id, med } = removeMedTarget;
    const r = await api(`/api/health/visit-medications?visit_id=${visit_id}&medication_id=${med.id}`, { method: 'DELETE' });
    if (r.error) { toast.error(r.error.message); return; }
    toast.success(`已从本次就诊移除「${med.name}」`);
    setRemoveMedTarget(null);
    if (selectedProfile) {
      const r2 = await api(`/api/health/profiles/${selectedProfile.id}/detail`);
      if (r2.data) {
        setSelectedProfile(r2.data);
        const freshVisit = (r2.data.visits || []).find(v => v.id === visit_id);
        if (freshVisit) setVisitDialog(d => d.initial?.id === visit_id ? { ...d, initial: freshVisit } : d);
      }
    }
  };

  // ── 保险记录已迁移至「财务」页面，本页不再管理保险 ──
  const confirmDelete = async () => {
    if (!deleteTarget) return;
    const { type, id } = deleteTarget;
    const tableMap = { profile: 'health_profiles', visit: 'health_visits', medication: 'health_medications' };
    const table = tableMap[type];
    const r = await api(`/api/${table}?filter=eq:id:${id}`, { method: 'DELETE' });
    if (r.error) { toast.error(r.error.message); return; }
    toast.success('已删除');
    setDeleteTarget(null);
    if (type === 'profile') { setSelectedProfile(null); loadProfiles(); }
    else if (selectedProfile) {
      // 就诊编辑弹窗还开着时（如从就诊里彻底删除药物），同步刷新其用药列表
      await loadDetail(selectedProfile.id);
      if (type === 'medication' && visitDialog.open && visitDialog.initial?.id) {
        const r2 = await api(`/api/health/profiles/${selectedProfile.id}/detail`);
        if (r2.data) {
          const freshVisit = (r2.data.visits || []).find(v => v.id === visitDialog.initial.id);
          if (freshVisit) setVisitDialog(d => ({ ...d, initial: freshVisit }));
        }
      }
    }
  };

  // ── 档案列表视图 ─────────────────────────────────────────
  if (!selectedProfile) {
    return (
      <div className="h-full flex flex-col bg-[#f5f5f5]">
        {/* 顶部标题栏 */}
        <div className="flex items-center justify-between gap-3 px-4 sm:px-6 py-3 bg-white border-b border-gray-200">
          <div className="flex items-center gap-2 min-w-0">
            <Heart className="w-5 h-5 text-rose-500 flex-shrink-0" />
            <h1 className="text-base font-semibold">健康档案</h1>
            <Badge variant="secondary" className="text-xs ml-1">{profiles.length}</Badge>
          </div>
          <div className="flex items-center gap-2 min-w-0">
            <Button size="sm" onClick={() => setProfileDialog({ open: true, initial: null })} className="flex-shrink-0 active:scale-95">
              <Plus className="w-3.5 h-3.5 mr-1" /> 新增档案
            </Button>
            <span className="text-xs text-gray-400 hidden sm:inline">在「设置 → 家庭成员」中添加家人</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-6">
          {loading ? (
            <div className="flex items-center justify-center h-40 text-gray-400 text-sm">加载中...</div>
          ) : profiles.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-60 text-gray-400">
              <Heart className="w-12 h-12 mb-3 opacity-30" />
              <p className="text-sm mb-3">还没有健康档案</p>
              <Button size="sm" onClick={() => setProfileDialog({ open: true, initial: null })} className="bg-[#bbea3b] hover:bg-[#a8d435] text-black mb-3">
                <Plus className="w-4 h-4 mr-1" /> 新增档案
              </Button>
              <span className="text-xs text-gray-400">也可在「设置 → 家庭成员」中添加家人</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {profiles.map(p => {
                const nextDays = p.next_visit ? daysUntil(p.next_visit.next_visit_date) : null;
                const ageText = calcAge(p.birth_date);
                const gText = genderText(p.gender);
                return (
                  <div
                    key={p.id}
                    onClick={() => loadDetail(p.id)}
                    className="bg-white rounded-lg border border-gray-200 p-4 cursor-pointer hover:shadow-md transition-all active:scale-[0.98] relative overflow-hidden"
                  >
                    <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: p.color || '#ccc' }} />
                    {/* 头部：头像 + 姓名 + 年龄 */}
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-11 h-11 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0" style={{ backgroundColor: p.color || '#ccc' }}>
                        {p.patient_name.slice(0, 1)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm truncate">{p.patient_name}</span>
                          {p.status === 'archived' && <Badge variant="secondary" className="text-xs">已归档</Badge>}
                        </div>
                        <div className="text-xs text-gray-400 mt-0.5">
                          {ageText}{ageText && gText ? ' · ' : ''}{gText}
                        </div>
                      </div>
                    </div>
                    {/* 疾病 */}
                    <div className="text-sm font-medium text-gray-700 mb-3 truncate">{p.disease_name}</div>
                    {/* 统计信息 */}
                    <div className="space-y-1.5 text-xs text-gray-500">
                      {p.last_visit && (
                        <div className="flex items-center gap-1.5">
                          <CalendarIcon className="w-3.5 h-3.5 flex-shrink-0" />
                          <span className="truncate">最近就诊：{formatDate(p.last_visit.visit_date)} {p.last_visit.hospital}</span>
                        </div>
                      )}
                      {p.active_medication_count > 0 && (
                        <div className="flex items-center gap-1.5">
                          <Pill className="w-3.5 h-3.5 flex-shrink-0" />
                          <span>服用药物：{p.active_medication_count} 种</span>
                        </div>
                      )}
                      {p.visit_count > 0 && (
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                          <span>就诊次数：{p.visit_count}</span>
                        </div>
                      )}
                    </div>
                    {/* 下次就诊提醒 */}
                    {nextDays !== null && (
                      <div className={`mt-3 px-2.5 py-1.5 rounded-md text-xs flex items-center gap-1.5 ${nextDays <= 3 ? 'bg-rose-50 text-rose-600' : nextDays <= 7 ? 'bg-amber-50 text-amber-600' : 'bg-gray-50 text-gray-500'}`}>
                        {nextDays <= 3 && <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />}
                        <span className="truncate">下次就诊：{formatDateRange(p.next_visit.next_visit_date, p.next_visit.next_visit_date_end)}</span>
                        <span className="flex-shrink-0">{nextDays > 0 ? `(${nextDays}天后)` : nextDays === 0 ? '(今天)' : '(已过期)'}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <ProfileFormDialog
          open={profileDialog.open}
          onClose={() => setProfileDialog({ open: false, initial: null })}
          onSubmit={saveProfile}
          initial={profileDialog.initial}
        />
        <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
          <AlertDialogContent>
            <AlertDialogHeader><AlertDialogTitle>确认删除</AlertDialogTitle></AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>取消</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="bg-red-500 hover:bg-red-600">删除</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    );
  }

  // ── 档案详情视图 ─────────────────────────────────────────
  return (
    <div className="h-full flex flex-col bg-[#f5f5f5]">
      {/* 顶部标题栏 */}
      <div className="flex items-center justify-between gap-2 px-4 sm:px-6 py-3 bg-white border-b border-gray-200">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <Button variant="ghost" size="sm" onClick={() => { setSelectedProfile(null); loadProfiles(); }} className="flex-shrink-0 active:scale-95">
            <ChevronLeft className="w-4 h-4" /> 返回
          </Button>
          <div className="h-4 w-px bg-gray-200 mx-0.5 flex-shrink-0" />
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-semibold flex-shrink-0" style={{ backgroundColor: selectedProfile.color || '#ccc' }}>
            {selectedProfile.patient_name.slice(0, 1)}
          </div>
          <div className="min-w-0">
            <span className="font-semibold text-sm block truncate">{selectedProfile.patient_name}</span>
            <span className="text-xs text-gray-400 block truncate">{selectedProfile.disease_name}</span>
          </div>
        </div>
        <div className="flex gap-1 flex-shrink-0">
          <Button variant="outline" size="sm" onClick={() => setProfileDialog({ open: true, initial: selectedProfile })} className="active:scale-95">编辑</Button>
          <Button variant="outline" size="sm" className="text-red-500 hover:text-red-600 active:scale-95" onClick={() => setDeleteTarget({ type: 'profile', id: selectedProfile.id, name: selectedProfile.patient_name })}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {detailLoading ? (
        <div className="flex items-center justify-center h-40 text-gray-400 text-sm">加载中...</div>
      ) : (
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-6 space-y-4">
          {/* 基本信息 */}
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
              <div>
                <div className="text-xs text-gray-400 mb-0.5">年龄</div>
                <div className="text-sm font-medium">{calcAge(selectedProfile.birth_date) || '-'}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-0.5">性别</div>
                <div className="text-sm font-medium">{genderText(selectedProfile.gender) || '-'}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-0.5">出生日期</div>
                <div className="text-sm font-medium">{formatDate(selectedProfile.birth_date) || '-'}</div>
                {selectedProfile.birth_lunar && selectedProfile.birth_date && (
                  <div className="text-xs text-gray-400 mt-0.5">农历 {lunarDateText(selectedProfile.birth_date)}</div>
                )}
              </div>
              <div>
                <div className="text-xs text-gray-400 mb-0.5">就诊次数</div>
                <div className="text-sm font-medium">{selectedProfile.visits?.length || 0}</div>
              </div>
            </div>
            {selectedProfile.notes && (
              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="text-xs text-gray-400 mb-1">备注</div>
                <p className="text-sm">{selectedProfile.notes}</p>
              </div>
            )}
          </div>

          {/* 药物记录 — 该档案全部药物的纯净列表，点击直接编辑药物并关联就诊 */}
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Pill className="w-4 h-4 text-green-500" />
                <h3 className="text-sm font-semibold">药物记录</h3>
                {allMedications.length > 0 && <Badge variant="secondary" className="text-xs">{allMedications.length}</Badge>}
              </div>
              <Button size="sm" variant="outline" onClick={() => setMedDialog({ open: true, initial: null, visitId: null })} className="active:scale-95">
                <Plus className="w-3.5 h-3.5 mr-1" /> 添加药物
              </Button>
            </div>
            {allMedications.length === 0 ? (
              <p className="text-xs text-gray-400 py-6 text-center">暂无药物记录</p>
            ) : (
              <div className="space-y-2">
                {allMedications.map(med => {
                  // 该药物关联的就诊日期（从 visit_ids 反查）
                  const linkedVisitDates = (med.visit_ids || [])
                    .map(vid => {
                      const v = (selectedProfile?.visits || []).find(x => x.id === vid);
                      return v ? formatDate(v.visit_date) : null;
                    })
                    .filter(Boolean);
                  return (
                    <div
                      key={med.id}
                      className="flex items-start gap-3 p-3 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => setMedDialog({ open: true, initial: med, visitId: null })}
                    >
                      {/* 药物图片 */}
                      <div
                        className="w-12 h-12 rounded-md flex items-center justify-center flex-shrink-0 overflow-hidden bg-green-50"
                        onClick={e => { if (med.photo_url) { e.stopPropagation(); setPreviewImage(med.photo_url); } }}
                      >
                        {med.photo_url
                          ? <img src={toThumbUrl(med.photo_url, 200)} alt={med.name} loading="lazy" className="w-full h-full object-cover" />
                          : <Pill className="w-5 h-5 text-green-500" />}
                      </div>
                      {/* 药物信息 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-medium">{med.name}</span>
                          <MedicationStatusBadge status={med.status} />
                        </div>
                        {med.dosage && <div className="text-xs text-gray-500 mt-1">{med.dosage}</div>}
                        {med.usage_instruction && <div className="text-xs text-gray-400 mt-0.5">{med.usage_instruction}</div>}
                        {(med.start_date || med.end_date) && (
                          <div className="text-xs text-gray-400 mt-0.5">
                            {formatDateRange(med.start_date, med.end_date) || '未设日期'}
                            {med.start_date && !med.end_date && ' ~ 至今'}
                          </div>
                        )}
                        {/* 关联的就诊记录 */}
                        {linkedVisitDates.length > 0
                          ? <div className="text-xs text-gray-400 mt-0.5">关联就诊：{linkedVisitDates.join('、')}</div>
                          : <div className="text-xs text-gray-300 mt-0.5">未关联就诊</div>}
                      </div>
                      {/* 操作按钮 */}
                      <div className="flex gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={() => setMedDialog({ open: true, initial: med, visitId: null })}
                          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-md transition-colors active:scale-90"
                          aria-label="编辑"
                        >
                          <Pill className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteTarget({ type: 'medication', id: med.id, name: med.name })}
                          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors active:scale-90"
                          aria-label="删除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* 就诊历史时间轴 — 整行可点击打开编辑 */}
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <CalendarIcon className="w-4 h-4 text-blue-500" />
                <h3 className="text-sm font-semibold">就诊记录</h3>
                <Badge variant="secondary" className="text-xs">{selectedProfile.visits?.length || 0}</Badge>
              </div>
              <Button size="sm" variant="outline" onClick={() => setVisitDialog({ open: true, initial: null })} className="active:scale-95">
                <Plus className="w-3.5 h-3.5 mr-1" /> 添加就诊
              </Button>
            </div>
            {selectedProfile.visits?.length === 0 ? (
              <p className="text-xs text-gray-400 py-6 text-center">暂无就诊记录</p>
            ) : (
              <div className="space-y-1">
                {selectedProfile.visits?.map((v) => {
                  const visitMeds = v.medications || [];
                  return (
                    <div
                      key={v.id}
                      onClick={() => setVisitDialog({ open: true, initial: v })}
                      className="relative pl-6 py-3 border-l-2 border-gray-100 last:border-l-0 cursor-pointer hover:bg-gray-50 active:bg-gray-100 rounded-r-md transition-colors -ml-2 pl-4"
                    >
                      <div className="absolute left-[3px] top-4 w-2 h-2 rounded-full bg-blue-400" />
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          {/* 就诊日期 + 医院 + 报销标签 */}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-medium">{formatDate(v.visit_date)}</span>
                            {v.hospital && <span className="text-xs text-gray-500">{v.hospital}</span>}
                            {v.department && <Badge variant="outline" className="text-xs">{v.department}</Badge>}
                            {v.doctor && <span className="text-xs text-gray-400">{v.doctor}医生</span>}
                            {/* 报销标签 */}
                            {v.is_reimbursed ? (
                              <Badge className="text-xs bg-green-100 text-green-700 hover:bg-green-100">{v.reimburse_amount != null ? `已报销 ¥${Number(v.reimburse_amount).toFixed(2)}` : '已报销'}</Badge>
                            ) : (
                              v.cost != null && <Badge variant="outline" className="text-xs text-gray-400">未报销</Badge>
                            )}
                          </div>
                          {/* 就诊详情（主诉/用药/检查/诊断合并；兼容旧数据） */}
                          {(v.chief_complaint || v.prescription || v.examination || v.diagnosis) && (
                            <div className="text-xs text-gray-600 mt-1.5 whitespace-pre-wrap">
                              {v.chief_complaint}
                              {v.prescription && `${v.chief_complaint ? '\n' : ''}用药：${v.prescription}`}
                              {v.examination && `${(v.chief_complaint || v.prescription) ? '\n' : ''}检查：${v.examination}`}
                              {v.diagnosis && `${(v.chief_complaint || v.prescription || v.examination) ? '\n' : ''}诊断：${v.diagnosis}`}
                            </div>
                          )}
                          {/* 本次用药 */}
                          {visitMeds.length > 0 && (
                            <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                              <Pill className="w-3 h-3 text-green-500 flex-shrink-0" />
                              {visitMeds.map(med => (
                                <span key={med.id} className="text-xs px-1.5 py-0.5 rounded bg-green-50 text-green-700">
                                  {med.name}
                                </span>
                              ))}
                            </div>
                          )}
                          {/* 费用 + 下次就诊 */}
                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-400 flex-wrap">
                            {v.cost != null && <span>费用：¥{Number(v.cost).toFixed(2)}</span>}
                            {(v.next_visit_date || v.next_visit_date_end) && (
                              <span className="text-amber-600">下次就诊：{formatDateRange(v.next_visit_date, v.next_visit_date_end)}</span>
                            )}
                          </div>
                          {/* 就诊附件图片 */}
                          {Array.isArray(v.attachment_urls) && v.attachment_urls.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-2">
                              {v.attachment_urls.map((att, idx) => (
                                <div key={idx} className="relative group">
                                  <img
                                    src={toThumbUrl(att.url, 200)}
                                    alt={`附件${idx + 1}`}
                                    loading="lazy"
                                    className="w-14 h-14 sm:w-16 sm:h-16 rounded-md object-cover border border-gray-200 cursor-pointer hover:opacity-80 transition-opacity"
                                    onClick={(e) => { e.stopPropagation(); setPreviewImage(att.url); }}
                                  />
                                  {att.note && (
                                    <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs px-1.5 py-0.5 rounded-b-md truncate max-w-full">
                                      {att.note}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        {/* 删除按钮（阻止冒泡，避免触发行点击） */}
                        <button
                          onClick={(e) => { e.stopPropagation(); setDeleteTarget({ type: 'visit', id: v.id, name: '就诊记录' }); }}
                          className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors active:scale-90 flex-shrink-0"
                          aria-label="删除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      <ProfileFormDialog
        open={profileDialog.open}
        onClose={() => setProfileDialog({ open: false, initial: null })}
        onSubmit={saveProfile}
        initial={profileDialog.initial}
      />
      <VisitFormDialog
        open={visitDialog.open}
        onClose={() => setVisitDialog({ open: false, initial: null })}
        onSubmit={saveVisit}
        initial={visitDialog.initial}
        profileId={selectedProfile?.id}
        lastVisit={selectedProfile?.visits?.[0] || null}
        visitMedications={visitDialog.initial?.medications || []}
        onAddMedication={(visitId) => setMedDialog({ open: true, initial: null, visitId })}
        onPickMedication={(visitId) => setMedPicker({ open: true, visitId })}
        onEditMedication={(med) => setMedDialog({ open: true, initial: med, visitId: visitDialog.initial?.id })}
        onDeleteMedication={(med) => setRemoveMedTarget({ visit_id: visitDialog.initial?.id, med })}
        onPreviewImage={setPreviewImage}
      />
      <MedicationFormDialog
        open={medDialog.open}
        onClose={() => setMedDialog({ open: false, initial: null, visitId: null })}
        onSubmit={saveMed}
        initial={medDialog.initial}
        profileId={selectedProfile?.id}
        visitId={medDialog.visitId}
        visits={selectedProfile?.visits || []}
      />
      <MedPickerDialog
        open={medPicker.open}
        onClose={() => setMedPicker({ open: false, visitId: null })}
        onConfirm={handleAddMedications}
        onAddNew={() => {
          setMedPicker({ open: false, visitId: null });
          setMedDialog({ open: true, initial: null, visitId: medPicker.visitId });
        }}
        medications={allMedications}
        currentMedIds={(visitDialog.initial?.medications || []).map(m => m.id)}
      />
      <AlertDialog open={!!deleteTarget} onOpenChange={(v) => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除「{deleteTarget?.name}」？</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-500 hover:bg-red-600">删除</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 从本次就诊移除药物：区分解除关联 / 彻底删除 */}
      <AlertDialog open={!!removeMedTarget} onOpenChange={(v) => !v && setRemoveMedTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>移除「{removeMedTarget?.med?.name}」</AlertDialogTitle>
            <AlertDialogDescription>
              仅从本次就诊移除，还是彻底删除该药物？解除关联后药物仍保留在药物库，可再次加入其他就诊记录。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col gap-2 sm:flex-col">
            <AlertDialogAction
              onClick={handleRemoveMedFromVisit}
              className="w-full bg-[#bbea3b] hover:bg-[#a8d435] text-black"
            >
              仅从本次就诊移除
            </AlertDialogAction>
            <AlertDialogAction
              onClick={() => {
                const med = removeMedTarget?.med;
                setRemoveMedTarget(null);
                if (med) setDeleteTarget({ type: 'medication', id: med.id, name: med.name });
              }}
              className="w-full bg-red-500 hover:bg-red-600"
            >
              彻底删除药物
            </AlertDialogAction>
            <AlertDialogCancel className="w-full mt-0">取消</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 图片预览 Modal */}
      <ImagePreviewModal
        src={previewImage}
        onClose={() => setPreviewImage(null)}
        onRotated={(newUrl) => {
          if (!newUrl) return;
          const oldUrl = previewImage;
          setPreviewImage(newUrl);
          // 同步正在编辑的弹窗：服务端已改 DB 且旧文件已删除，弹窗里的旧 URL 必须替换掉
          setVisitDialog(d => d.initial ? {
            ...d,
            initial: {
              ...d.initial,
              attachment_urls: (d.initial.attachment_urls || []).map(a => a.url === oldUrl ? { ...a, url: newUrl } : a),
              medications: (d.initial.medications || []).map(m => m.photo_url === oldUrl ? { ...m, photo_url: newUrl } : m),
            },
          } : d);
          setMedDialog(d => d.initial?.photo_url === oldUrl ? { ...d, initial: { ...d.initial, photo_url: newUrl } } : d);
          if (selectedProfile) loadDetail(selectedProfile.id);
        }}
      />
    </div>
  );
};

export default HealthPage;
