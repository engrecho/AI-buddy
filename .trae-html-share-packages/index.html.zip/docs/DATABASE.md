# AI-Buddy 数据库结构说明

> 最后更新：2026-07-18
> 数据库：MySQL 5.7+ / 8.0
> 部署位置：腾讯云宝塔（生产）/ 本地（开发）
> 协议：自建 Express HTTP API

---

## 连接信息

| 配置项 | 值 |
|--------|-----|
| 数据库类型 | MySQL 5.7+ / 8.0 |
| 主机 | localhost（仅本机访问） |
| 端口 | 3306 |
| 数据库名 | `buddy` |
| 用户名 | `buddy` |
| 字符集 | `utf8mb4` / `utf8mb4_unicode_ci` |
| 协议 | 自建 REST API（`/api/:table` 与 `/api/v1/*`） |
| 鉴权 | JWT Cookie（前端） / `X-API-Key` Header（buddy-skill） |

环境变量见 `.env.example`；后端连接池配置在 `server/db.js`。

---

## 数据表总览

| 表名 | 用途 | 主键类型 | 是否软删 |
|------|------|----------|----------|
| `users` | 用户 | AUTO_INCREMENT | 否 |
| `api_keys` | 外部工具的 API Key | AUTO_INCREMENT | 否（`is_active=false` 或 `expires_at` 过期） |
| `tasks` | 核心任务 | 手写 bigint | 否 |
| `task_groups` | 任务分组 / 看板泳道 | 手写 bigint | 否 |
| `task_members` | 人员 | AUTO_INCREMENT | 否 |
| `task_tags` | 任务标签 | 手写 bigint | 否 |
| `task_comments` | 任务评论 / 动态 | AUTO_INCREMENT | 否 |
| `memos` | 备忘录 | AUTO_INCREMENT | **是**（`deleted_at`） |
| `task_notes` | 梳理文档 | 手写 bigint | 否 |
| `reading_items` | 阅读收藏 | 手写 bigint | **是**（`deleted_at`） |
| `quick_notes` | 随记 | AUTO_INCREMENT | 否 |
| `health_profiles` | 健康档案（就诊人） | AUTO_INCREMENT | 否 |
| `health_visits` | 就诊记录 | AUTO_INCREMENT | 否 |
| `health_medications` | 用药记录 | AUTO_INCREMENT | 否 |
| `visit_medications` | 药物 ↔ 就诊 多对多关联 | AUTO_INCREMENT | 否 |
| `vault_items` | 密码保险箱（加密存储） | AUTO_INCREMENT | **是**（`deleted_at`） |
| `loans` | 贷款主表 | AUTO_INCREMENT | 否 |
| `loan_payments` | 还款计划表 | AUTO_INCREMENT | 否 |
| `health_insurances` | 家庭保险 | AUTO_INCREMENT | 否 |

**主键约定**：
- 早期版本统一用「手写 bigint（`Date.now()` 时间戳）」；迁移到 MySQL 后，POST 接口要求 DB 给出 `insertId`，因此部分表改为 `AUTO_INCREMENT`（详见 `deploy/migrate-add-auto-increment.sql`）
- 业务代码用 `src/lib/utils.js` 的 `genId()` 生成时间戳大整数

**用户隔离**：除 `users` 表外，所有业务表都带 `user_id`。后端 `parseFilters` 自动注入 `WHERE user_id = ?` 条件，前端无法绕过。

---

## 1. users（用户表）

```sql
CREATE TABLE `users` (
    `id`            BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `username`      VARCHAR(64) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,        -- bcrypt
    `nickname`      VARCHAR(255),
    `avatar_url`    TEXT,
    `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `last_login_at` TIMESTAMP NULL
);
```

- 密码用 `bcryptjs` 哈希（10 rounds）
- 登录后端用 `username + password` → 返回 JWT（存 Cookie `ai_buddy_token`）

---

## 2. api_keys（外部工具 API Key）

```sql
CREATE TABLE `api_keys` (
    `id`            BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`       BIGINT NOT NULL,
    `key_hash`      VARCHAR(64) NOT NULL UNIQUE,  -- SHA256(api_key) hex
    `key_prefix`    VARCHAR(20) NOT NULL,         -- 明文前 12 字符，仅展示
    `name`          VARCHAR(100) DEFAULT 'Default',
    `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
    `last_used_at`  TIMESTAMP NULL,
    `expires_at`    TIMESTAMP NULL,                -- NULL = 永不过期
    `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- **明文只显示一次**（在创建弹窗里）
- 存 SHA-256 哈希（明文 → 64 字符 hex）
- 鉴权流程见 `buddy-skill/SKILL.md` 和 `server/auth.js` 的 `getUserByApiKey`

---

## 3. tasks（核心任务表）

```sql
CREATE TABLE `tasks` (
    `id`              BIGINT NOT NULL PRIMARY KEY,
    `user_id`         BIGINT NOT NULL,
    `title`           TEXT NOT NULL,
    `description`     LONGTEXT,                       -- Tiptap HTML
    `status`          VARCHAR(20) NOT NULL DEFAULT 'todo',  -- todo/in_progress/done/archived
    `priority`        VARCHAR(20) DEFAULT 'medium',         -- low/medium/high/urgent
    `parent_id`       BIGINT,                              -- 子任务层级
    `is_project`      TINYINT(1) DEFAULT 0,
    `progress`        INT DEFAULT 0,                        -- 0-100
    `due_date`        TIMESTAMP NULL,
    `plan_date`       TIMESTAMP NULL,
    `owner_id`        BIGINT,
    `supporter_id`    BIGINT,
    `related_member_ids` JSON,
    `owner_ids`          JSON,
    `supporter_ids`      JSON,
    `group_id`        BIGINT,
    `tag_ids`         JSON,
    `key_docs`        JSON,
    `related_dx`      JSON,
    `predecessor_ids` JSON,                                -- 前置任务
    `successor_ids`   JSON,                                -- 后续任务
    `related_memo_ids` JSON,
    `need_report`     TINYINT(1) DEFAULT 0,
    `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- 状态：todo / in_progress / done / archived
- 优先级：low / medium / high / urgent
- `parent_id` 关联本表 id，做子任务层级
- `predecessor_ids` / `successor_ids` 是任务依赖图（梳理视图里渲染为流程图）

---

## 4. task_groups（任务分组 / 看板泳道）

```sql
CREATE TABLE `task_groups` (
    `id`         BIGINT NOT NULL PRIMARY KEY,
    `user_id`    BIGINT NOT NULL,
    `name`       VARCHAR(255) NOT NULL,
    `color`      VARCHAR(20),                -- #rrggbb
    `sort_order` INT,
    `keywords`   JSON,                        -- 自动归类用
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

**预设分组**（注册时自动创建，参见 `server/auth.js` `createDefaultGroupsForUser`）：
品牌发展 / 营运标准 / 加盟商管 / 产运数据 / 日常管理 / 个人项目 / 其他

---

## 5. task_members（人员）

```sql
CREATE TABLE `task_members` (
    `id`         BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`    BIGINT NOT NULL,
    `name`       VARCHAR(255) NOT NULL,
    `mis`        VARCHAR(255),
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## 6. task_tags（任务标签）

```sql
CREATE TABLE `task_tags` (
    `id`         BIGINT NOT NULL PRIMARY KEY,
    `name`       VARCHAR(255) NOT NULL,
    `color`      VARCHAR(20),
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## 7. task_comments（任务评论 / 动态）

```sql
CREATE TABLE `task_comments` (
    `id`           BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`      BIGINT NOT NULL,
    `task_id`      BIGINT NOT NULL,
    `content`      LONGTEXT,
    `comment_type` VARCHAR(20) DEFAULT 'comment',  -- comment / progress / issue
    `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- 三种类型：评论（comment）、进度更新（progress）、问题（issue）

---

## 8. memos（备忘录） — 软删

```sql
CREATE TABLE `memos` (
    `id`               BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`          BIGINT NOT NULL,
    `title`            VARCHAR(500),
    `content`          LONGTEXT,                            -- Tiptap HTML
    `memo_type`        VARCHAR(50) DEFAULT 'note',         -- note / idea / article
    `direction`        VARCHAR(255),
    `related_url`      TEXT,
    `related_task_id`  BIGINT,
    `related_task_ids` JSON,
    `reading_item_id`  VARCHAR(255),
    `tag_ids`          JSON,
    `tags`             TEXT,                                -- 字符串标签（与 JSON tag_ids 并存）
    `deleted_at`       TIMESTAMP NULL,                      -- 软删标记
    `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- 删除会更新 `deleted_at`，列表查询自动过滤 `deleted_at IS NULL`
- 同一份数据同时存了 `tag_ids`（JSON 数组）和 `tags`（字符串），前者给程序用、后者给搜索用

---

## 9. task_notes（梳理文档）

```sql
CREATE TABLE `task_notes` (
    `id`               BIGINT NOT NULL PRIMARY KEY,
    `user_id`          BIGINT NOT NULL,
    `title`            VARCHAR(500),
    `content`          LONGTEXT,                       -- Tiptap HTML + task-mention chip
    `related_task_ids` JSON,
    `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

- 内容含富文本 + 任务引用 chip（`@TaskName`），见 `src/components/TaskMentionExtension.js`

---

## 10. reading_items（阅读收藏） — 软删

```sql
CREATE TABLE `reading_items` (
    `id`         BIGINT NOT NULL PRIMARY KEY,
    `user_id`    BIGINT NOT NULL,
    `url`        TEXT NOT NULL,
    `title`      VARCHAR(500),
    `summary`    LONGTEXT,
    `category`   VARCHAR(100) DEFAULT 'work',
    `is_read`    TINYINT(1) DEFAULT 0,
    `is_starred` TINYINT(1) DEFAULT 0,
    `tags`       JSON,
    `deleted_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## 11. quick_notes（随记）

```sql
CREATE TABLE `quick_notes` (
    `id`         BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`    BIGINT NOT NULL,
    `content`    TEXT NOT NULL,
    `tags`       TEXT,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## 12. health_profiles（健康档案 — 就诊人）

```sql
CREATE TABLE `health_profiles` (
    `id`          BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`     BIGINT NOT NULL,
    `patient_name` VARCHAR(100) NOT NULL,         -- 患者姓名（如：张三 / 父亲）
    `id_card`     VARCHAR(32) NULL,                -- 身份证号（家庭成员管理用）
    `relationship` VARCHAR(32) NULL,               -- 与本人关系：本人/妻子/丈夫/女儿/儿子/母亲/父亲/其他
    `member_id`   BIGINT NULL,                     -- 关联的家庭成员ID（health_profiles.id 自关联）
    `gender`      ENUM('male','female') NULL,      -- 性别
    `birth_date`  DATE NULL,                       -- 出生日期（统一存公历，可空）
    `birth_lunar` TINYINT(1) DEFAULT 0,            -- 生日是否按阴历（农历）记
    `blood_type`  VARCHAR(10) NULL,                -- 血型
    `allergies`   TEXT NULL,                       -- 过敏史
    `medical_history` TEXT NULL,                    -- 既往病史
    `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- 一个用户可有多个档案（自己、父母、子女）
- `id_card` / `relationship` 于 2026-09 新增，用于「设置 → 家庭成员」管理与保险「被保人」关联
- `member_id` 于 2026-09 新增（`health_profiles` 自关联）：健康档案选择家人后绑定，避免重复录入；服务启动时在 `server/index.js` 幂等自愈（查 `information_schema` 再加列+索引），另附一次性脚本 `deploy/once/19-add-health-member-link.sh`
- `birth_lunar` 于 2026-09 新增：标识生日是否按农历记；`birth_date` 统一存公历，需农历展示时前端用 `src/lib/lunar.js` 双向换算（覆盖 1900–2100 年）
- `birth_date` 后端返回 ISO 字符串（如 `2021-11-14T16:00:00.000Z`），前端用本地时区转换显示

---

## 13. health_visits（就诊记录）

```sql
CREATE TABLE `health_visits` (
    `id`                 BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`            BIGINT NOT NULL,
    `profile_id`        BIGINT NOT NULL,            -- 关联 health_profiles.id
    `visit_date`        DATE NOT NULL,              -- 就诊日期
    `hospital`          VARCHAR(255) NULL,          -- 医院
    `department`        VARCHAR(100) NULL,          -- 科室
    `doctor`            VARCHAR(100) NULL,          -- 医生
    `chief_complaint`   TEXT NULL,                  -- 主诉
    `diagnosis`         TEXT NULL,                  -- 诊断结果
    `prescription`      TEXT NULL,                  -- 处方/用药方案
    `examination`       TEXT NULL,                  -- 检查报告
    `next_visit_date`       DATE NULL,              -- 下次就诊日期（开始，可空）
    `next_visit_date_end`   DATE NULL,              -- 下次就诊日期（结束，可空，支持区间）
    `cost`              DECIMAL(10,2) NULL,         -- 费用
    `is_reimbursed`     TINYINT(1) NOT NULL DEFAULT 0,  -- 是否报销（0=否, 1=是）
    `reimburse_amount`  DECIMAL(10,2) NULL,         -- 报销金额
    `attachment_urls`   JSON NULL,                  -- 附件图片（数组，每项 {url, note?}）
    `created_at`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- `next_visit_date` / `next_visit_date_end` 支持日期区间（前端用级联选择器）
- `is_reimbursed` 是布尔字段（`BOOLEAN_COLUMNS` 已配置）
- `attachment_urls` 是 JSON 数组：`[{url: "...", note: "心电图"}, ...]`，note 非必填
- 列表按 `visit_date DESC` 排序，`visits[0]` 即最新就诊

---

## 14. health_medications（用药记录）

```sql
CREATE TABLE `health_medications` (
    `id`               BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`          BIGINT NOT NULL,
    `profile_id`      BIGINT NOT NULL,              -- 关联 health_profiles.id
    `visit_id`        BIGINT NULL,                  -- 关联 health_visits.id（可空，表示独立用药）
    `name`            VARCHAR(200) NOT NULL,         -- 药品名称
    `dosage`          VARCHAR(100) NULL,             -- 剂量
    `usage_instruction` TEXT NULL,                  -- 用法说明
    `status`          ENUM('active','paused','completed','as_needed') NOT NULL DEFAULT 'active',
    `start_date`      DATE NULL,                     -- 开始日期（可空）
    `end_date`        DATE NULL,                     -- 结束日期（可空）
    `photo_url`       TEXT NULL,                     -- 药物照片
    `notes`           TEXT NULL,                     -- 备注
    `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- `status` 状态：`active`(服用中) / `paused`(暂停) / `completed`(已完成) / `as_needed`(酌情使用)
- `start_date` / `end_date` 均可空（支持无固定周期的药物）
- 药物与就诊记录为**多对多**关联（通过 `visit_medications` 关联表），`visit_id` 列已废弃仅保留兼容；未关联任何就诊的药物归到档案顶层"用药清单"
- 后端 `GET /api/health/profiles/:id/detail` 详情接口通过关联表分组：
  - `visits[].medications` = 本次就诊的药物（每个药物带 `visit_ids` 数组，即它关联的所有就诊 id）
  - `profile.medications` = 未关联就诊的顶层药物
- 关联管理接口：
  - `POST /api/health/visit-medications` `{ visit_id, medication_ids: [] }` 批量把药物加入某就诊
  - `DELETE /api/health/visit-medications?visit_id=&medication_id=` 从某就诊移除药物（仅解除关联）
  - `POST /api/health/medication-visits` `{ medication_id, visit_ids: [] }` 全量覆盖某药物的就诊关联
- 删除就诊/药物时自动清理 `visit_medications` 孤儿关联

### 14.1 visit_medications（药物 ↔ 就诊记录 多对多关联）

```sql
CREATE TABLE `visit_medications` (
  `id`            BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `visit_id`      BIGINT NOT NULL,
  `medication_id` BIGINT NOT NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_visit_med` (`visit_id`, `medication_id`),
  KEY `idx_vm_medication` (`medication_id`)
);
```

- 服务端启动时自动建表，并把存量 `health_medications.visit_id` 一对一数据迁移进本表（幂等）

---

## 15. vault_items（密码保险箱） — 软删

```sql
CREATE TABLE `vault_items` (
  `id`              BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `user_id`         BIGINT NOT NULL,
  `category`        VARCHAR(20) NOT NULL DEFAULT 'password',  -- password/apikey/card/note
  `title`           VARCHAR(200) NOT NULL,                     -- 标题
  `username`        VARCHAR(255) DEFAULT NULL,                  -- 用户名
  `phone`           VARCHAR(20) DEFAULT NULL,                   -- 手机号
  `email`           VARCHAR(255) DEFAULT NULL,                   -- 邮箱
  `login_methods`   JSON DEFAULT NULL,                          -- 支持的登录方式（多选数组：phone/wechat/qq/google）
  `cipher_secret`   TEXT NOT NULL,                              -- AES-256-CBC 加密后的密码/密钥
  `url`             TEXT DEFAULT NULL,                          -- 关联网址（明文）
  `cipher_notes`    TEXT DEFAULT NULL,                          -- AES-256-CBC 加密后的备注
  `is_active`       TINYINT(1) NOT NULL DEFAULT 1,              -- 状态：1=使用中, 0=已废弃
  `tags`            JSON DEFAULT NULL,
  `deleted_at`      TIMESTAMP NULL DEFAULT NULL,
  `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `idx_vault_items_user` (`user_id`, `deleted_at`, `category`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

- **加密存储**：`cipher_secret` 和 `cipher_notes` 用 AES-256-CBC 加密（密钥在服务端 `.env` 的 `VAULT_ENCRYPTION_KEY`）
- **解锁机制**：调用 `POST /api/vault/unlock` 用登录密码验证身份，签发 1 小时有效的 `vault_token`，存 localStorage
- **明文返回**：列表接口不返回明文密码；单条详情接口需要 `X-Vault-Token` Header 才返回 `secret` / `notes` 明文
- **`category` 分类**：`password`(账号密码) / `apikey`(API Key) / `card`(银行卡) / `note`(敏感备忘)
- **`login_methods` 登录方式**（多选 JSON 数组）：
  - `phone` —— 手机号登录
  - `wechat` —— 微信登录
  - `qq` —— QQ 登录
  - `google` —— 谷歌登录
- **`is_active` 状态**：1=使用中 / 0=已废弃，前端表单用下拉选择
- **搜索**：列表接口的 `keyword` 参数会模糊匹配 `title` / `username` / `phone` / `email`
- **软删**：删除是更新 `deleted_at`，列表查询自动过滤 `deleted_at IS NULL`

### 前端 API 路径

| 路径 | 方法 | 说明 |
|------|------|------|
| `/api/vault/unlock` | POST | 解锁（用登录密码换 vault_token，1 小时有效） |
| `/api/vault/items` | GET | 列表（返回元数据，不含明文密码；支持 `category` / `keyword` / `is_active` 查询参数） |
| `/api/vault/items` | POST | 创建条目（前端传明文，后端加密存储） |
| `/api/vault/items/:id` | GET | 详情（需 `X-Vault-Token` Header，返回明文 `secret` / `notes`） |
| `/api/vault/items/:id` | PATCH | 更新字段 |
| `/api/vault/items/:id` | DELETE | 软删 |

---

## 类型映射表（后端自动处理）

| JS 类型 | MySQL 类型 | 转换逻辑 |
|---------|-----------|----------|
| ISO 8601 字符串 | `TIMESTAMP` | `2026-07-01T17:06:28.081Z` ↔ `2026-07-01 17:06:28` |
| boolean | `TINYINT(1)` | `true` ↔ `1` |
| 对象/数组 | `JSON` | `JSON.stringify` ↔ `JSON.parse` |
| string | `VARCHAR` / `TEXT` / `LONGTEXT` | 直传 |
| number | `BIGINT` / `INT` | 直传 |

转换实现见 `server/index.js` `prepareValue` / `transformRow`。

---

## 软删约定

- `memos` 和 `reading_items` 的删除是软删（更新 `deleted_at`）
- 列表查询（GET）自动加 `WHERE deleted_at IS NULL`
- 软删后 `getById` 返回 200 + `data: null`（不是 404）
- 物理删除需要直接走 SQL

---

## 索引

- 所有表的主键索引
- `users.username` UNIQUE
- `api_keys.key_hash` UNIQUE（高频查询）
- `tasks.status`、`tasks.group_id`、`tasks.parent_id`、`tasks.owner_id`、`tasks.updated_at DESC`、`tasks.created_at DESC`
- `memos.user_id`、`memos.deleted_at`、`memos.created_at DESC`、`memos.updated_at DESC`
- `reading_items.deleted_at`、`reading_items.created_at DESC`
- `task_comments.task_id`、`task_comments.user_id`、`task_comments.created_at DESC`
- 其他业务常用外键也都加了索引

---

## 初始化与迁移

```bash
# 首次初始化（清空重建）
mysql -u buddy -p'密码' buddy < deploy/mysql-schema.sql

# 升级：单独跑迁移脚本（不会清空数据）
mysql -u buddy -p'密码' buddy < deploy/migrate-add-user-id.sql
mysql -u buddy -p'密码' buddy < deploy/migrate-add-api-keys.sql
mysql -u buddy -p'密码' buddy < deploy/migrate-add-auto-increment.sql
```

迁移脚本历史：
- `migrate-add-user-id.sql`：早期表加 `user_id` 字段
- `migrate-add-api-keys.sql`：新增 `api_keys` 表
- `migrate-add-auto-increment.sql`：把部分手写 bigint 改为 AUTO_INCREMENT（满足 SKILL POST 接口需要 `insertId`）

---

## 16. loans（贷款主表）

```sql
CREATE TABLE `loans` (
    `id`               BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`          BIGINT NOT NULL,
    `name`             VARCHAR(255) NOT NULL,                        -- 贷款名称
    `loan_type`        ENUM('mortgage','car','consumer','credit_card','other') NOT NULL DEFAULT 'other',  -- 贷款类型
    `institution`      VARCHAR(255) NULL,                            -- 贷款机构
    `principal`        DECIMAL(12,2) NOT NULL,                       -- 本金
    `annual_rate`      DECIMAL(6,4) NOT NULL,                        -- 年利率（如 0.0485 表示 4.85%）
    `term_months`      INT NOT NULL,                                 -- 期数（月）
    `repayment_method` ENUM('equal_payment','equal_principal') NOT NULL DEFAULT 'equal_payment',  -- 还款方式
    `start_date`       DATE NOT NULL,                                -- 放款日
    `repayment_day`    TINYINT NOT NULL DEFAULT 1,                   -- 每月还款日（1-28）
    `status`           ENUM('active','paid_off','closed') NOT NULL DEFAULT 'active',  -- 状态
    `notes`            TEXT NULL,                                    -- 备注
    `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- `loan_type` 贷款类型：`mortgage`(房贷) / `car`(车贷) / `consumer`(消费贷) / `credit_card`(信用卡分期) / `other`(其他)
- `repayment_method` 还款方式：`equal_payment`(等额本息) / `equal_principal`(等额本金)
- `status` 状态：`active`(还款中) / `paid_off`(已结清) / `closed`(已关闭)
- `annual_rate` 用小数存年利率（4.85% 存为 `0.0485`）
- 创建贷款时后端按 `repayment_method` + `principal` + `annual_rate` + `term_months` + `start_date` + `repayment_day` 自动生成 `loan_payments` 还款计划

---

## 17. loan_payments（还款计划表）

```sql
CREATE TABLE `loan_payments` (
    `id`               BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`          BIGINT NOT NULL,
    `loan_id`          BIGINT NOT NULL,                              -- 关联 loans.id
    `installment`      INT NOT NULL,                                 -- 第几期（从 1 开始）
    `due_date`         DATE NOT NULL,                                -- 应还日期
    `due_amount`       DECIMAL(12,2) NOT NULL,                       -- 应还总额（本金+利息）
    `principal_amount` DECIMAL(12,2) NOT NULL,                       -- 本金部分
    `interest_amount`  DECIMAL(12,2) NOT NULL,                       -- 利息部分
    `paid_amount`      DECIMAL(12,2) NOT NULL DEFAULT 0,             -- 已还金额
    `paid_date`        DATE NULL,                                    -- 实际还款日
    `status`           ENUM('pending','paid','overdue','partial') NOT NULL DEFAULT 'pending',  -- 状态
    `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- `loan_id` 关联 `loans.id`，创建贷款时自动生成全部期数的还款记录
- `status` 状态：`pending`(待还) / `paid`(已还) / `overdue`(逾期) / `partial`(部分还款)
- 支持手动标记已还 / 撤销（前端 `PATCH /api/loan-payments/:id/mark`）
- 前端展示规则：3 天内到期标橙色、逾期标红色

---

## 18. health_insurances（家庭保险）

```sql
CREATE TABLE `health_insurances` (
    `id`                BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`           BIGINT NOT NULL,
    `profile_id`        BIGINT NULL,                                 -- 关联 health_profiles.id（可空）
    `name`              VARCHAR(255) NOT NULL,                       -- 保险名称
    `insurance_type`    ENUM('critical_illness','medical','accident','life','car','property','other') NOT NULL DEFAULT 'other',  -- 保险类型
    `company`           VARCHAR(255) NULL,                           -- 保险公司
    `policy_no`         VARCHAR(100) NULL,                           -- 保单号
    `insured_person`    VARCHAR(100) NULL,                           -- 被保人
    `coverage_amount`   DECIMAL(12,2) NULL,                          -- 保额
    `annual_premium`    DECIMAL(12,2) NULL,                          -- 年保费
    `effective_date`    DATE NULL,                                   -- 生效日
    `expiry_date`       DATE NULL,                                   -- 到期日
    `payment_frequency` ENUM('yearly','monthly','onetime') NOT NULL DEFAULT 'yearly',  -- 缴费频率
    `auto_renew`        TINYINT(1) NOT NULL DEFAULT 0,               -- 是否自动续保
    `beneficiary`       VARCHAR(255) NULL,                           -- 身故受益人
    `beneficiary_ratio` VARCHAR(100) NULL,                           -- 受益比例
    `coverage_terms`    TEXT NULL,                                   -- 赔付条件
    `status`            ENUM('active','expired','lapsed','canceled') NOT NULL DEFAULT 'active',  -- 状态
    `notes`             TEXT NULL,                                   -- 备注
    `created_at`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

- `profile_id` 可空：关联到具体健康档案（就诊人），也可不关联直接作为家庭保险
- `insurance_type` 保险类型：`critical_illness`(重疾) / `medical`(医疗) / `accident`(意外) / `life`(寿险) / `car`(车险) / `property`(家财险) / `other`(其他)
- `payment_frequency` 缴费频率：`yearly`(年缴) / `monthly`(月缴) / `onetime`(一次性)
- `status` 状态：`active`(有效) / `expired`(过期) / `lapsed`(失效) / `canceled`(已退保)
- `auto_renew` 是布尔字段（`BOOLEAN_COLUMNS` 已配置）
- 前端展示规则：到期日临近 7 天标红提醒

---

## 备份与恢复

```bash
# 备份
mysqldump -u buddy -p'密码' buddy > /www/backup/buddy_$(date +%Y%m%d).sql

# 恢复
mysql -u buddy -p'密码' buddy < backup_20260704.sql

# 仅备份结构
mysqldump -u buddy -p'密码' --no-data buddy > schema.sql
```

自动备份脚本见 `docs/TROUBLESHOOTING.md` 末尾。
