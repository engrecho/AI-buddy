import mysql from 'mysql2/promise';

// â”€â”€ æ•°æ®åº“è¿žæŽ¥æ±  â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '3306', 10),
  user: process.env.DB_USER || 'buddy',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'buddy',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4',
  dateStrings: false,
});

// â”€â”€ è¡¨ç»“æž„å®šä¹‰ï¼ˆç”¨äºŽåˆ—åéªŒè¯å’? SQL æ³¨å…¥é˜²æŠ¤ï¼‰â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// æ³¨æ„ï¼šåŒ…å? user_id çš„è¡¨éœ€è¦ç”¨æˆ·ç™»å½•åŽæ‰èƒ½è®¿é—®
export const TABLE_COLUMNS = {
  // ç”¨æˆ·è¡¨ï¼ˆç‰¹æ®Šï¼Œä¸å‚ä¸Žé€šç”¨ CRUD è·¯ç”±ï¼?
  users: [
    'id', 'username', 'password_hash', 'nickname', 'avatar_url',
    'created_at', 'last_login_at'
  ],
  // ä¸šåŠ¡è¡¨ï¼ˆéœ€è¦? user_id è¿‡æ»¤ï¼?
  tasks: [
    'id', 'user_id', 'title', 'description', 'status', 'priority', 'parent_id',
    'is_project', 'progress', 'due_date', 'plan_date', 'owner_id',
    'supporter_id', 'related_member_ids', 'owner_ids', 'supporter_ids',
    'group_id', 'tag_ids', 'key_docs', 'related_dx', 'predecessor_ids',
    'successor_ids', 'related_memo_ids', 'created_at', 'updated_at'
  ],
  task_groups: [
    'id', 'user_id', 'name', 'color', 'sort_order', 'keywords',
    'created_at', 'updated_at'
  ],
  task_members: [
    'id', 'user_id', 'name', 'mis', 'created_at'
  ],
  task_tags: [
    'id', 'user_id', 'name', 'color', 'created_at'
  ],
  task_comments: [
    'id', 'user_id', 'task_id', 'content', 'comment_type', 'created_at'
  ],
  memos: [
    'id', 'user_id', 'title', 'content', 'memo_type', 'direction', 'related_url',
    'related_task_id', 'related_task_ids', 'reading_item_id', 'tag_ids',
    'tags', 'deleted_at', 'created_at', 'updated_at'
  ],
  task_notes: [
    'id', 'user_id', 'title', 'content', 'related_task_ids', 'created_at', 'updated_at'
  ],
  reading_items: [
    'id', 'user_id', 'url', 'platform', 'title', 'summary', 'cover_url', 'category',
    'is_read', 'is_starred', 'is_offline', 'offline_path', 'tags',
    'deleted_at', 'created_at'
  ],
  quick_notes: [
    'id', 'user_id', 'content', 'tags', 'created_at'
  ],
  // RSS è®¢é˜…æº?
  rss_sources: [
    'id', 'user_id', 'name', 'url', 'description', 'site_url', 'color',
    'last_fetched_at', 'last_status', 'last_error', 'article_count',
    'created_at', 'updated_at'
  ],
  // RSS æ–‡ç« 
  rss_articles: [
    'id', 'user_id', 'source_id', 'guid', 'url', 'title', 'summary', 'content',
    'cover_url', 'author', 'categories', 'published_at', 'is_read', 'is_starred',
    'created_at', 'updated_at'
  ],
  // â”€â”€ å¥åº·æ¡£æ¡ˆæ¨¡å— â”€â”€
  health_profiles: [
    'id', 'user_id', 'patient_name', 'patient_avatar_url', 'id_card', 'relationship', 'member_id',
    'gender', 'birth_date', 'birth_lunar', 'disease_name', 'color', 'tags', 'status', 'notes',
    'deleted_at', 'created_at', 'updated_at'
  ],
  health_visits: [
    'id', 'user_id', 'profile_id', 'visit_date', 'hospital', 'department', 'doctor',
    'chief_complaint', 'diagnosis', 'prescription', 'examination', 'next_visit_date',
    'next_visit_date_end', 'cost', 'is_reimbursed', 'reimburse_amount',
    'attachment_urls', 'created_at', 'updated_at'
  ],
  health_medications: [
    'id', 'user_id', 'profile_id', 'visit_id', 'name', 'photo_url',
    'usage_instruction', 'dosage', 'start_date', 'end_date', 'status', 'notes',
    'created_at', 'updated_at'
  ],
  vault_items: [
    'id', 'user_id', 'category', 'title', 'username', 'phone', 'email', 'login_methods',
    'cipher_secret', 'url', 'cipher_notes', 'is_active', 'tags',
    'deleted_at', 'created_at', 'updated_at'
  ],
  loans: [
    'id', 'user_id', 'name', 'loan_type', 'institution', 'principal', 'annual_rate',
    'term_months', 'repayment_method', 'start_date', 'repayment_day', 'status', 'notes',
    'created_at', 'updated_at'
  ],
  loan_payments: [
    'id', 'user_id', 'loan_id', 'installment', 'due_date', 'due_amount',
    'principal_amount', 'interest_amount', 'paid_amount', 'paid_date', 'status',
    'created_at', 'updated_at'
  ],
  health_insurances: [
    'id', 'user_id', 'profile_id', 'name', 'insurance_type', 'company', 'policy_no',
    'insured_person', 'coverage_amount', 'annual_premium', 'effective_date', 'expiry_date',
    'payment_frequency', 'auto_renew', 'beneficiary', 'beneficiary_ratio',
    'coverage_terms', 'status', 'notes', 'created_at', 'updated_at'
  ],
};

// â”€â”€ ä¸éœ€è¦ç™»å½•çš„å…¬å¼€è¡¨ï¼ˆåªè¯»ï¼Œç”¨äºŽç³»ç»Ÿé¢„è®¾æ•°æ®ï¼‰â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
// å½“å‰æ‰€æœ‰è¡¨éƒ½éœ€è¦ç™»å½?
export const PUBLIC_TABLES = new Set();

// â”€â”€ JSON ç±»åž‹åˆ? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export const JSON_COLUMNS = {
  tasks: [
    'related_member_ids', 'owner_ids', 'supporter_ids', 'tag_ids',
    'key_docs', 'related_dx', 'predecessor_ids', 'successor_ids', 'related_memo_ids'
  ],
  task_groups: ['keywords'],
  memos: ['related_task_ids', 'tag_ids'],
  task_notes: ['related_task_ids'],
  reading_items: ['tags'],
  rss_articles: ['categories'],
  health_profiles: ['tags'],
  health_visits: ['attachment_urls'],
  vault_items: ['tags', 'login_methods'],
};

// â”€â”€ DATETIME åˆ? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export const DATETIME_COLUMNS = {
  tasks: ['due_date', 'plan_date', 'created_at', 'updated_at'],
  task_groups: ['created_at', 'updated_at'],
  task_members: ['created_at'],
  task_tags: ['created_at'],
  task_comments: ['created_at'],
  memos: ['deleted_at', 'created_at', 'updated_at'],
  task_notes: ['created_at', 'updated_at'],
  reading_items: ['deleted_at', 'created_at'],
  quick_notes: ['created_at'],
  users: ['created_at', 'last_login_at'],
  rss_sources: ['last_fetched_at', 'created_at', 'updated_at'],
  rss_articles: ['published_at', 'created_at', 'updated_at'],
  health_profiles: ['birth_date', 'deleted_at', 'created_at', 'updated_at'],
  health_visits: ['visit_date', 'next_visit_date', 'next_visit_date_end', 'created_at', 'updated_at'],
  health_medications: ['start_date', 'end_date', 'created_at', 'updated_at'],
  vault_items: ['deleted_at', 'created_at', 'updated_at'],
  loans: ['start_date', 'created_at', 'updated_at'],
  loan_payments: ['due_date', 'paid_date', 'created_at', 'updated_at'],
  health_insurances: ['effective_date', 'expiry_date', 'created_at', 'updated_at'],
};

// â”€â”€ BOOLEAN åˆ? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export const BOOLEAN_COLUMNS = {
  tasks: ['is_project'],
  reading_items: ['is_read', 'is_starred', 'is_offline'],
  rss_articles: ['is_read', 'is_starred'],
  vault_items: ['is_active'],
  health_visits: ['is_reimbursed'],
  health_insurances: ['auto_renew'],
};
